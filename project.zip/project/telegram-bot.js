const { Telegraf } = require('telegraf');
const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const Database = require('./database');
const config = require('./config');

class TelegramBot {
  constructor() {
    this.bot = new Telegraf(config.telegram.botToken);
    this.db = new Database();
    this.client = null;
    this.forwardingRules = new Map();
    this.init();
  }

  async init() {
    await this.loadForwardingRules();
    this.setupBotHandlers();
    this.setupTelegramClient();
  }

  async setupTelegramClient() {
    try {
      const stringSession = new StringSession(config.telegram.sessionString);
      this.client = new TelegramClient(stringSession, parseInt(config.telegram.apiId), config.telegram.apiHash, {
        connectionRetries: 5,
      });

      await this.client.start({
        phoneNumber: config.telegram.phoneNumber,
        password: async () => {
          return new Promise((resolve) => {
            // In production, implement proper 2FA handling
            console.log('2FA password required');
            resolve('your-2fa-password');
          });
        },
        phoneCode: async () => {
          return new Promise((resolve) => {
            // In production, implement proper code input
            console.log('Phone code required');
            resolve('12345');
          });
        },
        onError: (err) => console.log('Telegram client error:', err),
      });

      console.log('Telegram client connected successfully');
    } catch (error) {
      console.error('Failed to setup Telegram client:', error);
    }
  }

  setupBotHandlers() {
    // Start command
    this.bot.start((ctx) => {
      ctx.reply('Welcome to Telegram Group Manager Bot!\n\nCommands:\n/help - Show help\n/addgroup - Add current group to management\n/listgroups - List managed groups\n/status - Bot status');
    });

    // Help command
    this.bot.help((ctx) => {
      const helpText = `
🤖 Telegram Group Manager Bot

Available Commands:
/start - Start the bot
/help - Show this help message
/addgroup - Add current group to management
/listgroups - List all managed groups
/status - Show bot status
/members - Show group members (admins only)

Admin Commands:
/forward <source_id> <target_id> - Setup message forwarding
/stopforward <rule_id> - Stop forwarding rule
/addmember <user_id> - Add member to current group
/removemember <user_id> - Remove member from current group

For advanced management, use the web admin panel.
      `;
      ctx.reply(helpText);
    });

    // Add group command
    this.bot.command('addgroup', async (ctx) => {
      try {
        const chat = ctx.chat;
        if (chat.type === 'private') {
          return ctx.reply('This command can only be used in groups!');
        }

        await this.db.addGroup(chat.id.toString(), chat.title, 'managed');
        ctx.reply(`✅ Group "${chat.title}" has been added to management!`);
      } catch (error) {
        console.error('Error adding group:', error);
        ctx.reply('❌ Error adding group to management.');
      }
    });

    // List groups command
    this.bot.command('listgroups', async (ctx) => {
      try {
        const groups = await this.db.getGroups();
        if (groups.length === 0) {
          return ctx.reply('No groups are currently managed.');
        }

        let message = '📋 Managed Groups:\n\n';
        groups.forEach((group, index) => {
          message += `${index + 1}. ${group.group_name} (${group.group_type})\n`;
          message += `   ID: ${group.group_id}\n\n`;
        });

        ctx.reply(message);
      } catch (error) {
        console.error('Error listing groups:', error);
        ctx.reply('❌ Error retrieving groups.');
      }
    });

    // Status command
    this.bot.command('status', async (ctx) => {
      try {
        const groups = await this.db.getGroups();
        const rules = await this.db.getForwardingRules();
        const members = await this.db.getMembers();

        const statusMessage = `
🔍 Bot Status:

📊 Statistics:
• Managed Groups: ${groups.length}
• Forwarding Rules: ${rules.length}
• Total Members: ${members.length}

🤖 Bot Status: Online
🔗 Client Status: ${this.client ? 'Connected' : 'Disconnected'}
        `;

        ctx.reply(statusMessage);
      } catch (error) {
        console.error('Error getting status:', error);
        ctx.reply('❌ Error retrieving status.');
      }
    });

    // Members command (admin only)
    this.bot.command('members', async (ctx) => {
      try {
        const chat = ctx.chat;
        if (chat.type === 'private') {
          return ctx.reply('This command can only be used in groups!');
        }

        // Check if user is admin
        const member = await ctx.getChatMember(ctx.from.id);
        if (!['creator', 'administrator'].includes(member.status)) {
          return ctx.reply('❌ You need to be an admin to use this command.');
        }

        const members = await this.db.getGroupMembers(chat.id.toString());
        if (members.length === 0) {
          return ctx.reply('No members found in database for this group.');
        }

        let message = `👥 Group Members (${members.length}):\n\n`;
        members.forEach((member, index) => {
          message += `${index + 1}. ${member.first_name || 'Unknown'} ${member.last_name || ''}`;
          if (member.username) message += ` (@${member.username})`;
          message += `\n   Status: ${member.status}\n\n`;
        });

        ctx.reply(message);
      } catch (error) {
        console.error('Error listing members:', error);
        ctx.reply('❌ Error retrieving members.');
      }
    });

    // Forward setup command
    this.bot.command('forward', async (ctx) => {
      try {
        const args = ctx.message.text.split(' ');
        if (args.length !== 3) {
          return ctx.reply('Usage: /forward <source_group_id> <target_group_id>');
        }

        const sourceId = args[1];
        const targetId = args[2];

        await this.db.addForwardingRule(sourceId, targetId);
        await this.loadForwardingRules();

        ctx.reply(`✅ Forwarding rule created: ${sourceId} → ${targetId}`);
      } catch (error) {
        console.error('Error creating forwarding rule:', error);
        ctx.reply('❌ Error creating forwarding rule.');
      }
    });

    // Message forwarding handler
    this.bot.on('message', async (ctx) => {
      try {
        const chatId = ctx.chat.id.toString();

        if (this.forwardingRules.has(chatId)) {
          const targetGroups = this.forwardingRules.get(chatId);

          for (const targetId of targetGroups) {
            try {
              await ctx.telegram.copyMessage(
                targetId,
                ctx.chat.id,
                ctx.message.message_id
              );
            } catch (forwardError) {
              console.error(`Error forwarding to ${targetId}:`, forwardError);
            }
          }
        }

        // Store member information
        if (ctx.from) {
          await this.db.addMember(
            ctx.from.id.toString(),
            ctx.from.username,
            ctx.from.first_name,
            ctx.from.last_name,
            null
          );

          if (ctx.chat.type !== 'private') {
            await this.db.addMemberToGroup(chatId, ctx.from.id.toString());
          }
        }
      } catch (error) {
        console.error('Error handling message:', error);
      }
    });

    // Error handling
    this.bot.catch((err, ctx) => {
      console.error('Bot error:', err);
      ctx.reply('❌ An error occurred. Please try again.');
    });
  }

  async loadForwardingRules() {
    try {
      const rules = await this.db.getForwardingRules();
      this.forwardingRules.clear();

      rules.forEach(rule => {
        if (!this.forwardingRules.has(rule.source_group_id)) {
          this.forwardingRules.set(rule.source_group_id, []);
        }
        this.forwardingRules.get(rule.source_group_id).push(rule.target_group_id);
      });

      console.log(`Loaded ${rules.length} forwarding rules`);
    } catch (error) {
      console.error('Error loading forwarding rules:', error);
    }
  }

  async addMemberToGroup(groupId, userId) {
    try {
      if (!this.client) {
        throw new Error('Telegram client not connected');
      }

      // Use Telegram API to add member
      await this.client.invoke(
        new Api.channels.InviteToChannel({
          channel: groupId,
          users: [userId],
        })
      );

      // Update database
      await this.db.addMemberToGroup(groupId, userId);

      return { success: true, message: 'Member added successfully' };
    } catch (error) {
      console.error('Error adding member to group:', error);
      return { success: false, message: error.message };
    }
  }

  async removeMemberFromGroup(groupId, userId) {
    try {
      if (!this.client) {
        throw new Error('Telegram client not connected');
      }

      // Use Telegram API to remove member
      await this.client.invoke(
        new Api.channels.EditBanned({
          channel: groupId,
          userId: userId,
          bannedRights: new Api.ChatBannedRights({
            untilDate: 0,
            viewMessages: true,
          }),
        })
      );

      return { success: true, message: 'Member removed successfully' };
    } catch (error) {
      console.error('Error removing member from group:', error);
      return { success: false, message: error.message };
    }
  }

  async start() {
    try {
      await this.bot.launch();
      console.log('Telegram bot started successfully');
    } catch (error) {
      console.error('Error starting bot:', error);
    }
  }

  stop() {
    this.bot.stop('SIGINT');
    if (this.client) {
      this.client.disconnect();
    }
    this.db.close();
  }
}

module.exports = TelegramBot;