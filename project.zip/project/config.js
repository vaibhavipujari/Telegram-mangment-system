require('dotenv').config();

module.exports = {
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN,
    apiId: parseInt(process.env.TELEGRAM_API_ID),
    apiHash: process.env.TELEGRAM_API_HASH,
    sessionString: process.env.TELEGRAM_SESSION_STRING
  },
  admin: {
    host: process.env.HOST || "localhost",
    port: process.env.ADMIN_PORT || 3000,
    username: process.env.ADMIN_USERNAME || 'admin',
    password: process.env.ADMIN_PASSWORD || 'admin123',
    email: "admin@gmail.com"
  },
  database: {
    path: process.env.DATABASE_PATH || './database.sqlite'
  },
  features: {
    adminPanel: process.env.ADMIN_PANEL || true,
  },

  session: {
    secret: process.env.SESSION_SECRET || 'telegram-group-manager-secret'
  }
};