// File: database.js

const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const config = require('./config');

class Database {
  constructor() {
    this.db = new sqlite3.Database(config.database.path);
    this.init();
  }

  init() {
    this.db.serialize(() => {
      this.db.run(`
        CREATE TABLE IF NOT EXISTS Admin (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          email TEXT NOT NULL UNIQUE,
          content TEXT
        )
      `);

      this.db.run(`
        CREATE TABLE IF NOT EXISTS groups (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          chat_id TEXT UNIQUE NOT NULL,
          title TEXT NOT NULL,
          type TEXT NOT NULL,
          is_source BOOLEAN DEFAULT FALSE,
          is_target BOOLEAN DEFAULT FALSE,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      this.db.run(`
        CREATE TABLE IF NOT EXISTS members (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id TEXT NOT NULL,
          username TEXT,
          first_name TEXT,
          last_name TEXT,
          phone TEXT,
          group_id INTEGER,
          status TEXT DEFAULT 'pending',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (group_id) REFERENCES groups (id)
        )
      `);

      this.db.run(`
        CREATE TABLE IF NOT EXISTS message_forwards (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          source_group_id INTEGER,
          target_group_id INTEGER,
          message_id TEXT,
          forwarded_message_id TEXT,
          content TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (source_group_id) REFERENCES groups (id),
          FOREIGN KEY (target_group_id) REFERENCES groups (id)
        )
      `);
    });
  }

  // Admin Methods
  getAdminByUsername(username) {
    return new Promise((resolve, reject) => {
      this.db.get("SELECT * FROM Admin WHERE username = ?", [username], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }

  createAdmin(username, password, email, content = '') {
    return new Promise(async (resolve, reject) => {
      try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const query = `INSERT INTO Admin (username, password, email, content) VALUES (?, ?, ?, ?)`;
        this.db.run(query, [username, hashedPassword, email, content], function (err) {
          if (err) reject(err);
          else resolve({ success: true, adminId: this.lastID });
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  loginAdmin(username, inputPassword) {
    return new Promise((resolve, reject) => {
      this.db.get("SELECT * FROM Admin WHERE username = ?", [username], async (err, row) => {
        try {
          if (err) return reject(err);
          if (!row) return resolve({ success: false, message: 'Admin not found' });

          const match = await bcrypt.compare(inputPassword, row.password);
          if (match) resolve({ success: true, admin: row });
          else resolve({ success: false, message: 'Invalid password' });
        } catch (error) {
          reject(error);
        }
      });
    });
  }

  // Group Methods
  addGroup(chatId, title, type, isSource = false, isTarget = false) {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        INSERT OR REPLACE INTO groups (chat_id, title, type, is_source, is_target)
        VALUES (?, ?, ?, ?, ?)
      `);
      stmt.run([chatId, title, type, isSource, isTarget], function (err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  getGroups() {
    return new Promise((resolve, reject) => {
      this.db.all("SELECT * FROM groups ORDER BY created_at DESC", (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  getSourceGroups() {
    return new Promise((resolve, reject) => {
      this.db.all("SELECT * FROM groups WHERE is_source = 1", (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  getTargetGroups() {
    return new Promise((resolve, reject) => {
      this.db.all("SELECT * FROM groups WHERE is_target = 1", (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  // Member Methods
  addMember(userId, username, firstName, lastName, phone, groupId = null, status = 'pending') {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        INSERT OR REPLACE INTO members (user_id, username, first_name, last_name, phone, group_id, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run([userId, username, firstName, lastName, phone, groupId, status], function (err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  addMemberToGroup(groupId, userId) {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        UPDATE members SET group_id = ? WHERE user_id = ?
      `);
      stmt.run([groupId, userId], function (err) {
        if (err) reject(err);
        else resolve(this.changes > 0);
      });
      stmt.finalize();
    });
  }

  getMembers(groupId = null) {
    return new Promise((resolve, reject) => {
      let query = `
        SELECT m.*, g.title as group_title
        FROM members m
        LEFT JOIN groups g ON m.group_id = g.id
      `;
      const params = [];
      if (groupId) {
        query += " WHERE m.group_id = ?";
        params.push(groupId);
      }
      query += " ORDER BY m.created_at DESC";

      this.db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  getGroupMembers(groupId) {
    return new Promise((resolve, reject) => {
      this.db.all("SELECT * FROM members WHERE group_id = ? ORDER BY created_at DESC", [groupId], (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  // Forwarding Rules
  addForwardingRule(sourceGroupId, targetGroupId) {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        INSERT INTO message_forwards (source_group_id, target_group_id)
        VALUES (?, ?)
      `);
      stmt.run([sourceGroupId, targetGroupId], function (err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  getForwardingRules() {
    return new Promise((resolve, reject) => {
      this.db.all("SELECT * FROM message_forwards", (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  logMessageForward(sourceGroupId, targetGroupId, messageId, forwardedMessageId, content) {
    return new Promise((resolve, reject) => {
      const stmt = this.db.prepare(`
        INSERT INTO message_forwards (source_group_id, target_group_id, message_id, forwarded_message_id, content)
        VALUES (?, ?, ?, ?, ?)
      `);
      stmt.run([sourceGroupId, targetGroupId, messageId, forwardedMessageId, content], function (err) {
        if (err) reject(err);
        else resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  getForwardStats() {
    return new Promise((resolve, reject) => {
      this.db.all(`
        SELECT 
          COUNT(*) as total_forwards,
          COUNT(DISTINCT source_group_id) as source_groups,
          COUNT(DISTINCT target_group_id) as target_groups
        FROM message_forwards
      `, (err, row) => {
        if (err) reject(err);
        else resolve(row[0]);
      });
    });
  }

  close() {
    this.db.close();
  }
}

module.exports = Database;