const TelegramBot = require('./telegram-bot');
const AdminPanel = require('./admin-panel');
const config = require('./config');

class TelegramGroupManager {
  constructor() {
    this.telegramBot = null;
    this.adminPanel = null;
    this.init();
  }

  async init() {
    console.log('🚀 Starting Telegram Group Manager...');

    try {
      // Start admin panel
      if (config.features.adminPanel) {
        this.adminPanel = new AdminPanel();
        await this.adminPanel.start();
      }

      // Start Telegram bot
      this.telegramBot = new TelegramBot();
      await this.telegramBot.start();

      console.log('✅ Telegram Group Manager started successfully!');
      console.log('\n📋 Available Features:');
      console.log('• Message Forwarding: Enabled');
      console.log('• Member Management: Enabled');
      console.log('• Admin Panel: http://localhost:' + config.admin.port);
      console.log('\n🔐 Default Admin Credentials:');
      console.log('• Username:', config.admin.username);
      console.log('• Password:', config.admin.password);
      console.log('\n📖 Bot Commands:');
      console.log('• /start - Start the bot');
      console.log('• /addgroup - Add current group to management');
      console.log('• /listgroups - List managed groups');
      console.log('• /members - Show group members');
      console.log('• /forward <source> <target> - Setup forwarding');

    } catch (error) {
      console.error('❌ Error starting application:', error);
      process.exit(1);
    }
  }

  async stop() {
    console.log('🛑 Stopping Telegram Group Manager...');

    if (this.telegramBot) {
      this.telegramBot.stop();
    }

    console.log('✅ Application stopped successfully!');
    process.exit(0);
  }
}

// Handle graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🔄 Received SIGINT, shutting down gracefully...');
  if (global.app) {
    await global.app.stop();
  } else {
    process.exit(0);
  }
});

process.on('SIGTERM', async () => {
  console.log('\n🔄 Received SIGTERM, shutting down gracefully...');
  if (global.app) {
    await global.app.stop();
  } else {
    process.exit(0);
  }
});

// Start the application
const app = new TelegramGroupManager();
global.app = app;