const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const input = require("input");
require("dotenv").config();

const apiId = parseInt(process.env.TELEGRAM_API_ID, 10);
const apiHash = process.env.TELEGRAM_API_HASH;

const stringSession = new StringSession(""); // Empty for new session

(async () => {
    console.log("📲 Generating Telegram session string...");

    const client = new TelegramClient(stringSession, apiId, apiHash, {
        connectionRetries: 5,
        deviceModel: "iPhone 13 Pro Max",        // Spoofed device
        systemVersion: "15.3",                   // iOS version
        appVersion: "9.4.1",                     // Telegram app version
        langCode: "en",
        systemLangCode: "en-US",
        langPack: "tdesktop",                    // Fine to use on desktop
    });


    await client.start({
        phoneNumber: async () => await input.text("Enter phone number: "),
        password: async () => await input.text("Enter 2FA password (if set): "),
        phoneCode: async () => await input.text("Enter the code you received: "),
        onError: (err) => console.error("Login error:", err),
    });

    console.log("\n✅ Session successfully generated!");
    console.log("\nPaste this in your .env as TELEGRAM_SESSION_STRING:");
    console.log(client.session.save());
})();
