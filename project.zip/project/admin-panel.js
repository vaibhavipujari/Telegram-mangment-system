const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const Database = require('./database');
const TelegramBot = require('./telegram-bot');
const config = require('./config');

class AdminPanel {
  constructor() {
    this.app = express();
    this.db = new Database();
    this.telegramBot = null;
    this.init();
  }

  async init() {
    this.setupMiddleware();
    this.setupRoutes();
    await this.createDefaultAdmin();
  }

  setupMiddleware() {
    this.app.use(cors());
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'views'));

    // Session configuration
    this.app.use(session({
      secret: config.session.secret,
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 } // 24 hours
    }));
  }

  setupRoutes() {
    // Authentication middleware
    const requireAuth = (req, res, next) => {
      if (req.session.user) {
        next();
      } else {
        res.redirect('/login');
      }
    };

    // Login routes
    this.app.get('/login', (req, res) => {
      res.render('login', { error: null });
    });

    this.app.post('/login', async (req, res) => {
      try {
        const { username, password } = req.body;
        const user = await this.db.getAdminByUsername(username);
        console.log(user)

        if (user && await this.db.loginAdmin(username, password)) {
          req.session.user = { id: user.id, username: user.username };
          res.redirect('/dashboard');
        } else {
          res.render('login', { error: 'Invalid username or password' });
        }
      } catch (error) {
        console.error('Login error:', error);
        res.render('login', { error: 'Login failed' });
      }
    });

    // Logout route
    this.app.get('/logout', (req, res) => {
      req.session.destroy();
      res.redirect('/login');
    });

    // Dashboard route
    this.app.get('/', requireAuth, (req, res) => {
      res.redirect('/dashboard');
    });

    this.app.get('/dashboard', requireAuth, async (req, res) => {
      try {
        const groups = await this.db.getGroups();
        const rules = await this.db.getForwardingRules();
        const members = await this.db.getMembers();

        res.render('dashboard', {
          user: req.session.user,
          stats: {
            groups: groups.length,
            rules: rules.length,
            members: members.length
          },
          groups,
          rules,
          members: members.slice(0, 10) // Show only first 10 members
        });
      } catch (error) {
        console.error('Dashboard error:', error);
        res.render('dashboard', {
          user: req.session.user,
          stats: { groups: 0, rules: 0, members: 0 },
          groups: [],
          rules: [],
          members: []
        });
      }
    });

    // Groups management
    this.app.get('/groups', requireAuth, async (req, res) => {
      try {
        const groups = await this.db.getGroups();
        res.render('groups', { user: req.session.user, groups });
      } catch (error) {
        console.error('Groups error:', error);
        res.render('groups', { user: req.session.user, groups: [] });
      }
    });

    this.app.post('/groups/add', requireAuth, async (req, res) => {
      try {
        const { groupId, groupName, groupType } = req.body;
        await this.db.addGroup(groupId, groupName, groupType);
        res.redirect('/groups');
      } catch (error) {
        console.error('Add group error:', error);
        res.status(500).json({ error: 'Failed to add group' });
      }
    });

    // Forwarding rules management
    this.app.get('/forwarding', requireAuth, async (req, res) => {
      try {
        const rules = await this.db.getForwardingRules();
        const groups = await this.db.getGroups();
        res.render('forwarding', { user: req.session.user, rules, groups });
      } catch (error) {
        console.error('Forwarding error:', error);
        res.render('forwarding', { user: req.session.user, rules: [], groups: [] });
      }
    });

    this.app.post('/forwarding/add', requireAuth, async (req, res) => {
      try {
        const { sourceGroupId, targetGroupId } = req.body;
        await this.db.addForwardingRule(sourceGroupId, targetGroupId);

        // Reload forwarding rules in bot
        if (this.telegramBot) {
          await this.telegramBot.loadForwardingRules();
        }

        res.redirect('/forwarding');
      } catch (error) {
        console.error('Add forwarding rule error:', error);
        res.status(500).json({ error: 'Failed to add forwarding rule' });
      }
    });

    // Members management
    this.app.get('/members', requireAuth, async (req, res) => {
      try {
        const members = await this.db.getMembers();
        const groups = await this.db.getGroups();
        res.render('members', { user: req.session.user, members, groups });
      } catch (error) {
        console.error('Members error:', error);
        res.render('members', { user: req.session.user, members: [], groups: [] });
      }
    });

    this.app.post('/members/add', requireAuth, async (req, res) => {
      try {
        const { userId, username, firstName, lastName, phone } = req.body;
        await this.db.addMember(userId, username, firstName, lastName, phone);
        res.redirect('/members');
      } catch (error) {
        console.error('Add member error:', error);
        res.status(500).json({ error: 'Failed to add member' });
      }
    });

    this.app.post('/members/add-to-group', requireAuth, async (req, res) => {
      try {
        const { userId, groupId } = req.body;

        if (this.telegramBot) {
          const result = await this.telegramBot.addMemberToGroup(groupId, userId);
          res.json(result);
        } else {
          res.status(500).json({ error: 'Telegram bot not connected' });
        }
      } catch (error) {
        console.error('Add member to group error:', error);
        res.status(500).json({ error: 'Failed to add member to group' });
      }
    });

    this.app.post('/members/remove-from-group', requireAuth, async (req, res) => {
      try {
        const { userId, groupId } = req.body;

        if (this.telegramBot) {
          const result = await this.telegramBot.removeMemberFromGroup(groupId, userId);
          res.json(result);
        } else {
          res.status(500).json({ error: 'Telegram bot not connected' });
        }
      } catch (error) {
        console.error('Remove member from group error:', error);
        res.status(500).json({ error: 'Failed to remove member from group' });
      }
    });

    // API endpoints
    this.app.get('/api/stats', requireAuth, async (req, res) => {
      try {
        const groups = await this.db.getGroups();
        const rules = await this.db.getForwardingRules();
        const members = await this.db.getMembers();

        res.json({
          groups: groups.length,
          rules: rules.length,
          members: members.length
        });
      } catch (error) {
        console.error('Stats API error:', error);
        res.status(500).json({ error: 'Failed to get statistics' });
      }
    });

    // Bot control
    this.app.post('/api/bot/start', requireAuth, async (req, res) => {
      try {
        if (!this.telegramBot) {
          this.telegramBot = new TelegramBot();
          await this.telegramBot.start();
          res.json({ success: true, message: 'Bot started successfully' });
        } else {
          res.json({ success: false, message: 'Bot is already running' });
        }
      } catch (error) {
        console.error('Bot start error:', error);
        res.status(500).json({ error: 'Failed to start bot' });
      }
    });

    this.app.post('/api/bot/stop', requireAuth, async (req, res) => {
      try {
        if (this.telegramBot) {
          this.telegramBot.stop();
          this.telegramBot = null;
          res.json({ success: true, message: 'Bot stopped successfully' });
        } else {
          res.json({ success: false, message: 'Bot is not running' });
        }
      } catch (error) {
        console.error('Bot stop error:', error);
        res.status(500).json({ error: 'Failed to stop bot' });
      }
    });
  }

  async createDefaultAdmin() {
    try {
      const existingAdmin = await this.db.getAdminByUsername(config.admin.username);
      if (!existingAdmin) {
        const hashedPassword = await bcrypt.hash(config.admin.password, 10);
        await this.db.createAdmin(
          config.admin.username,
          hashedPassword,
          config.admin.email
        );
        console.log('Default admin created:', config.admin.defaultUsername);
      }
    } catch (error) {
      console.error('Error creating default admin:', error);
    }
  }


  async start() {
    try {
      this.app.listen(config.admin.port, () => {
        console.log(`Admin panel running on http://${config.admin.host}:${config.admin.port}`);
        console.log(`Default admin: ${config.admin.username} / ${config.admin.password}`);
      });
    } catch (error) {
      console.error('Error starting admin panel:', error);
    }
  }
}

module.exports = AdminPanel;